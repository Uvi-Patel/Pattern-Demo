//
//  ViewController.swift
//  Pattern_demo
//
//  Created by MAC on 18/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var clickBtn: UIButton!
    //@IBOutlet weak var Vieew: UIView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        clickBtn.addTarget(self, action: #selector(clickShow(_:)), for: .touchUpInside)
    

        
//        for i in 0..<5
//        {
//            var str = ""
//
//            for _ in 0...5 - i
//                {
//                    str.append(" ")
//                }
//            for _ in 0...i
//                {
//                    str.append("*")
//                }
//            print(str)
//        }
        
//        for i in 0..<5
//        {
//            var str = ""
//            for _ in 0...5 - i {
//                str.append(" ")
//            }
//
//            for _ in 0...i
//            {
//                str.append("*")
//            }
//            print(str)
//        }
//        for i in 0..<5
//        {
//            var str = ""
//            for _ in 0...i
//            {
//                str.append("*")
//            }
//            print(str)
//        }
        
        // Do any  additional setup after loading the view.
//        for i in 1...5
//        {
//           for _ in stride (from: 5, to: i, by: -1)
//          {
//            print(" ",terminator : "")
//          }
//          for _ in 1...i
//          {
//             print("*",terminator : "")
//          }
//
//          print("")
//        }
        
}

        @IBAction func clickShow(_ sender: Any) {
            
//            var str: String = ""
//            var n = Int(str)
//            n = Int(textField.text!)
//            for i in 0..<n!
//                {
//                for _ in 0...n! - i
//                    {
//                        str.append("")
//
//                    }
//                for _ in 0...i
//                    {
//                        str.append("* ")
//                        lbl.text = String(str)
//
//                    }
//                        str.append("\n")
//                        print(str)
//
//                }
            
            
            /*      left Tringle     */
            
//            var str: String = ""
//            var n = Int(str)
//            n = Int(textField.text!)
//            for i in 0..<n!
//            {
//               // var str = ""
//                for _ in 0...n! - i {
//                    str.append(" ")
//                }
//
//                for _ in 0...i
//                {
//                    str.append("*")
//                    lbl.text = String(str)
//                }
//                print(str)
//                str.append("\n")
//            }
      
           /*   Right Tringle   */
        
//          var str: String = ""
//          var n = Int(str)
//          n = Int(textField.text!)
//
//          for i in 1...n! {
//
//            for _ in 1...i
//              {
//                  str.append("* ")
//                  lbl.text = String(str)
//              }
//            print(str)
//              str.append("\n")
//          }
            
         /* Top to  Right Tringle   */
            
            var str: String = ""
            var n = Int(str)
            n = Int(textField.text!)

            for i in 0...n!
            {
                for _ in i...n!
                {
                    str.append("*")
                    lbl.text = String(str)
                }
                print(str)
                str.append("\n")
            }
            
             /* Top to  Left Tringle   */
            
//        var str: String = ""
//        var n = Int(str)
//        n = Int(textField.text!)
//
//        for i in 0...n! {
//            for _ in 0...n! + i
//            {
//                str.append(" ")
//            }
//
//            for _ in i...n!
//            {
//                str.append("*")
//                lbl.text = String(str)
//            }
//            print(str)
//            str.append("\n")
//
//        }
            
            
        /*      left Tringle     */
        
//        var str: String = ""
//        var n = Int(str)
//        n = Int(textField.text!)
//
//        for i in 1...n!
//        {
//
//            for _ in stride(from: n!, to: i, by: -1)
//            {
//                str.append(" ")
//               // print(" ", terminator: "")
//            }
//            for _ in 1...i
//            {
//                str.append("*")
//                lbl.text = String(str)
//                //print("*",terminator: "")
//            }
//            print(str)
//            str.append("\n")
//            //print(" ")
//        }
        
        
        /*  pyramid   */
        
//        var str: String = ""
//        var n = Int(str)
//        n = Int(textField.text!)
//
//        for i in 1...n!
//        {
//            for _ in stride(from: n!, to: i, by: -1)
//            {
//               str.append("")
//                print(terminator : " ")
//            }
//
//            for _ in 1...i
//            {
//                str.append("*")
//                lbl.text = String(str)
//                print("*",terminator : " ")
//            }
//            str.append("\n")
//
//            print("")
//        }

    }

}

